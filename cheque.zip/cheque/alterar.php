<?php
    require_once('ClassBD.php');
    $cheque = new Cheque();
?>
<div class="row">
    <div class="col-sm-3"></div>
    <div class="col-sm-6">
        <form action="index.php?page=engine" method="POST">        
        <div class="form-group">
            <label for="id">Nome</label>
            <select class="form-control" name="id" id="id">
                <?php $cheque->consultaNomes(); ?>
            </select>
            <input type="hidden" name="action" value="alterar">
        </div> 
        <button type="submit" class="btn btn-default">Alterar</button>
        </form> 
    </div>
    <div class="col-sm-3"></div> 
</div>