<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title>Sistema de consulta de cheques</title>
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>  
        <link rel="stylesheet" type="text/css" href="css/default.css" />      
    </head>
    <body>
        <div class="container-fluid center">
            <img src="img/logo.png" />            
        </div>
        <div class="container-fluid h-30"></div>
        <nav class="navbar navbar-inverse cor1">
            <div class="container-fluid cor1">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="index.php">Consultar</a></li>
                    <li><a href="index.php?page=novo">Novo</a></li>
                    <li><a href="index.php?page=alterar">Alterar</a></li>
                    <li><a href="index.php?page=excluir">Excluir</a></li>
                </ul>
            </div>
        </nav>
        <div class="container-fluid h-50"></div>
        <div class="container-fluid center">
            <?php 
                if(isset($_REQUEST['page'])){
                    include $_REQUEST['page'] . ".php";
                }else{
                    include "consultas.php";
                }
            ?>
        </div>
        <div class="container-fluid h-50"></div>
    </body>
</html>