<?php 
    require_once("ClassBD.php");
    $cheque = new Cheque();

    $action = $_REQUEST['action'];

    switch($action)
    {
        case 'consulta':
            $nome = $_REQUEST['nome'];
            $cheque->set('nome', $_REQUEST['nome']);
           
            echo "<div class='row'>";
                echo "<div class='col-sm-2'></div>";
                echo "<div class='col-sm-8'>";
                    $cheque->consulta();
                echo "</div>";
                echo "<div class='col-sm-3'></div>";    
            echo "</div>";
            echo "<div class='row'>";
                echo "<div class='col-sm-3'></div>";
                echo "<div class='col-sm-6'>
                    <form action='index.php' method='POST'>
                        <button type='submit' class='btn btn-default'>Voltar</button>
                    </form>
                </div>";
                echo "<div class='col-sm-2'></div>";    
            echo "</div>";
            
            break;



        case 'novo':

            $cheque->set('nome', $_REQUEST['nome']);
            $cheque->set('banco', $_REQUEST['banco']);
            $cheque->set('agencia', $_REQUEST['agencia']);
            $cheque->set('cc', $_REQUEST['cc']);
            $cheque->set('cpf_cnpj', $_REQUEST['cpf_cnpj']);
            $cheque->set('consulta', $_REQUEST['consulta']);
            $cheque->set('status', $_REQUEST['status']);

            if($answer = $cheque->cadastra()){
                echo "<h3><p class='bg-success'>Cadastrado com sucesso!</p></h3>";
            }else{
                echo "<h3><p class='bg-danger'>Falha ao cadastrar!</p></h3>";
            }          
            
            break; 
            

        
        case 'excluir':

            $cheque->set('id', $_REQUEST['id']);

            if($answer = $cheque->exclui()){
                echo "<h3><p class='bg-success'>Excluído com sucesso!</p></h3>";
            }else{
                echo "<h3><p class='bg-danger'>Falha ao excluir!</p></h3>";
            }          
            
            break; 


        
        case 'alterar':

            $cheque->set('id', $_REQUEST['id']);

            $cheque->consultaID();      
            
            break; 
            
            
            case 'alterarF':

            $cheque->set('id', $_REQUEST['id']);
            $cheque->set('nome', $_REQUEST['nome']);
            $cheque->set('banco', $_REQUEST['banco']);
            $cheque->set('agencia', $_REQUEST['agencia']);
            $cheque->set('cc', $_REQUEST['cc']);
            $cheque->set('cpf_cnpj', $_REQUEST['cpf_cnpj']);
            $cheque->set('consulta', $_REQUEST['consulta']);
            $cheque->set('status', $_REQUEST['status']);

            if($answer = $cheque->altera()){
                echo "<h3><p class='bg-success'>Alterado com sucesso!</p></h3>";
            }else{
                echo "<h3><p class='bg-danger'>Falha ao alterar!</p></h3>";
            }          
                  
            
            break; 
    }

?>