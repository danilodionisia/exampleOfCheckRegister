<div class="row">
    <div class="col-sm-3"></div>
    <div class="col-sm-6">
        <form action="index.php?page=engine" method="POST">
        <div class="form-group">
            <label for="nome">Nome</label>
            <input type="text" class="form-control" name="nome" id="nome">
            <input type="hidden" name="action" value="novo">
        </div>
        <div class="form-group">
            <label for="banco">Banco</label>
            <input type="text" class="form-control" name="banco" id="banco">
        </div>
        <div class="form-group">
            <label for="agencia">Agência</label>
            <input type="text" class="form-control" name="agencia" id="agencia">
        </div>
        <div class="form-group">
            <label for="cc">Conta Corrente</label>
            <input type="text" class="form-control" name="cc" id="cc">
        </div>
        <div class="form-group">
            <label for="cpf_cnpj">CPF/CNPJ</label>
            <input type="text" class="form-control" name="cpf_cnpj" id="cpf_cnpj">
        </div>
        <div class="form-group">
            <label for="consulta">Consultado?</label>
            <select class="form-control" name="consulta" id="consulta">
                <option value="nao">Não</option>
                <option value="sim">Sim</option>
            </select>
        </div> 
        <div class="form-group">
            <label for="status">Status</label>
            <select class="form-control" name="status" id="consulta">
                <option value="Sem Restricao">Sem Restricao</option>
                <option value="Com Restricao">Com Restricao</option>
            </select>
        </div> 
        <button type="submit" class="btn btn-default">Salvar</button>
        </form> 
    </div>
    <div class="col-sm-3"></div>
</div>