<?php 

    class Cheque{

        private $id;
        private $nome;
        private $banco;
        private $agencia;
        private $cc;
        private $cpf_cnpj;
        private $consulta;
        private $status;

        public function set($atributo, $valor){
            $this->$atributo = $valor;
        }

        public function get($atributo){
            return $this->$atributo;
        }

        private function conexao()
        {
            $user = "root";
            $password = "";
            $server = "localhost";
            $database = "cheque";
            
            $conn = mysqli_connect($server, $user, $password, $database) or die (mysqli_error($conn));

            return $conn;            
        }

        public function consulta()
        {
            $conn = $this->conexao();
            $sql = "SELECT * FROM cad_cheque WHERE nome LIKE '".$this->get('nome')."%'";
            $query = mysqli_query($conn, $sql) or die (mysqli_error($conn));
            mysqli_close($conn);

            if($rows = mysqli_num_rows($query) > 0){

                echo "<table class='table table-bordered'>
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Banco</th>
                                <th>AG</th>
                                <th>CC</th>
                                <th>CPF</th>
                            </tr>
                        </thead>
                        <tbody>";

                while($dados = mysqli_fetch_assoc($query)){
                    
                    echo "<tr>";
                        echo "<td>" . utf8_encode($dados['nome']) . "</td>";
                        echo "<td>" . utf8_encode($dados['banco']) . "</td>";
                        echo "<td>" . utf8_encode($dados['ag']) . "</td>";
                        echo "<td>" . utf8_encode($dados['cc']) . "</td>";
                        echo "<td>" . utf8_encode($dados['cpf']) . "</td>";
                    echo "</tr>";

                }

                echo "  <tbody>
                    </table>";

            }
        }

        public function cadastra()
        {
            $conn = $this->conexao();

            $sql = "INSERT INTO cad_cheque";
            $sql .= " VALUES ";
            $sql .= "(";
            $sql .= "'',";
            $sql .= "'".$this->get('nome')."',";
            $sql .= "'".$this->get('banco')."',";
            $sql .= "'".$this->get('agencia')."',";
            $sql .= "'".$this->get('cc')."',";
            $sql .= "'".$this->get('cpf_cnpj')."',";
            $sql .= "'".$this->get('consulta')."',";
            $sql .= "'".$this->get('status')."'";
            $sql .= ")";
            
            $query = mysqli_query($conn, $sql) or die (mysqli_error($conn));
            mysqli_close($conn);

            if($query){
                return true;
            }else{
                return false;
            }
           
        }

        public function consultaNomes()
        {
            $conn = $this->conexao();
            $sql = "SELECT id, nome FROM cad_cheque ORDER BY nome";
            $query = mysqli_query($conn, $sql) or die (mysqli_error($conn));
            mysqli_close($conn);

            if($rows = mysqli_num_rows($query) > 0){               

                while($dados = mysqli_fetch_assoc($query)){

                    echo "<option value='".$dados['id']."'>";
                    echo  utf8_encode($dados['nome']);
                    echo "</option>";
                }
            }
        }

        public function exclui()
        {
            $conn = $this->conexao();
            $sql = "DELETE FROM cad_cheque WHERE id = '".$this->get('id')."'";
            $query = mysqli_query($conn, $sql) or die (mysqli_error($conn));
            mysqli_close($conn);

            if($query){
                return true;
            }else{
                return false;
            }
        }


        public function consultaID()
        {
            $conn = $this->conexao();
            $sql = "SELECT * FROM cad_cheque WHERE id = '".$this->get('id')."'";
            $query = mysqli_query($conn, $sql) or die (mysqli_error($conn));
            mysqli_close($conn);

            if($rows = mysqli_num_rows($query) > 0)
            {
                $dados = mysqli_fetch_assoc($query);

                ?>

                <div class="row">
                    <div class="col-sm-3"></div>
                    <div class="col-sm-6">
                        <form action="index.php?page=engine" method="POST">
                        <div class="form-group">
                            <label for="nome">Nome</label>
                            <input type="text" class="form-control" name="nome" id="nome" value="<?php echo utf8_encode($dados['nome']); ?>">
                            <input type="hidden" name="id" value="<?php echo $this->get('id'); ?>">
                            <input type="hidden" name="action" value="alterarF">
                        </div>
                        <div class="form-group">
                            <label for="banco">Banco</label>
                            <input type="text" class="form-control" name="banco" id="banco" value="<?php echo utf8_encode($dados['banco']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="agencia">Agência</label>
                            <input type="text" class="form-control" name="agencia" id="agencia" value="<?php echo utf8_encode($dados['ag']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="cc">Conta Corrente</label>
                            <input type="text" class="form-control" name="cc" id="cc" value="<?php echo utf8_encode($dados['cc']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="cpf_cnpj">CPF/CNPJ</label>
                            <input type="text" class="form-control" name="cpf_cnpj" id="cpf_cnpj" value="<?php echo utf8_encode($dados['cpf']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="consulta">Consultado?</label>
                            <select class="form-control" name="consulta" id="consulta">
                                <option value="<?php echo utf8_encode($dados['consulta']); ?>"><?php echo utf8_encode($dados['consulta']); ?></option>
                                <option value="nao">Não</option>
                                <option value="sim">Sim</option>
                            </select>
                        </div> 
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select class="form-control" name="status" id="consulta">
                                <option value="<?php echo $dados['status']; ?>"><?php echo $dados['status']; ?></option>
                                <option value="Sem Restricao">Sem Restricao</option>
                                <option value="Com Restricao">Com Restricao</option>
                            </select>
                        </div> 
                        <button type="submit" class="btn btn-default">Salvar</button>
                        </form> 
                    </div>
                    <div class="col-sm-3"></div>
                </div>

                <?php 

            }
        }

        public function altera()
        {
            $conn = $this->conexao();

            $sql = "UPDATE cad_cheque";
            $sql .= " SET ";
            $sql .= "nome = '".$this->get('nome')."',";
            $sql .= "banco = '".$this->get('banco')."',";
            $sql .= "ag = '".$this->get('agencia')."',";
            $sql .= "cc = '".$this->get('cc')."',";
            $sql .= "cpf = '".$this->get('cpf_cnpj')."',";
            $sql .= "consulta = '".$this->get('consulta')."',";
            $sql .= "status = '".$this->get('status')."'";
            $sql .= "WHERE id = '".$this->get('id')."'";
            
            $query = mysqli_query($conn, $sql) or die (mysqli_error($conn));
            mysqli_close($conn);

            if($query){
                return true;
            }else{
                return false;
            }
           
        }

    }

?>