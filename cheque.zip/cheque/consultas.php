<div class="row">           
    <form action="index.php?page=engine" method="POST">                
        <div class="col-sm-3"></div>
        <div class="form-group col-sm-6">
            <label for="nome">Nome</label>
            <input type="text" name="nome" class="form-control" id="nome">
            <input type="hidden" name="action" value="consulta">
        </div> 
        <div class="col-sm-3"></div>
                
        <div class="col-sm-5"></div>
        <div class="form-group col-sm-2">   
            <button type="submit" class="btn btn-default">Pesquisar</button>
        </div>  
        <div class="col-sm-5"></div>
    </form>			
</div>